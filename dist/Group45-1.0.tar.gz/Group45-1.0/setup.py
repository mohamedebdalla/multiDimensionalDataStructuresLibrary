from setuptools import setup
import setuptools
setup(name='Group45',
      version='1.0',
      description='ENSF 338 Final Project',
      author='Aser-Ghobara',
      author_email ='aser.ghobara@ucalgary.ca',
      packages=setuptools.find_packages(),
      install_requires=[],
      )
