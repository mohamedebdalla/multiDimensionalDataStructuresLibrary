from setuptools import setup
import setuptools
setup(name='Group_45',
      version='1.1',
      description='ENSF 338 Final Project',
      author='Aser-Ghobara',
      author_email ='aser.ghobara@ucalgary.ca',
      packages=setuptools.find_packages(),
      install_requires=['pytest'],
      )
